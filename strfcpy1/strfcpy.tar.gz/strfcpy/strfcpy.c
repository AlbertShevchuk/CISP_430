#include <string.h>
#include "strfcpy.h"

char *strfcpy(char *dest, const char *src, const char *allow)
{
  char *oldDest = dest;
  while (*src)
  {
    if (strchr(allow, *src))
    {
      *(dest++) = *src;
    }
    ++src;
  }
  *dest = 0;
  return oldDest;
}
