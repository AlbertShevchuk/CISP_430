#ifndef _STRDCPY_H
#define _STRDCPY_H

char *strfcpy(char *dest, const char *src, const char *allow);

#endif
